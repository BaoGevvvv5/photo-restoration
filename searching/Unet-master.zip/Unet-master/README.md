# Unet
A demo of Unet to detect edges!  
   
- **[My CSDN Blog on how to use it](http://blog.csdn.net/awyyauqpmy/article/details/79290710)**
